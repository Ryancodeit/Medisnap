import { useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import PrescriptionEditor from '../components/PrescriptionEditor';
import { savePrescription } from '../components/Storage';

export default function ConfirmPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [extractedText] = useState(location.state?.extractedText || '');

  const handleConfirm = (medData) => {
    savePrescription(medData);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Confirm Details</h2>
          <p className="mt-2 text-sm text-gray-600">
            Review and edit the extracted information
          </p>
        </div>
        
        <div className="mt-8 bg-white p-6 rounded-lg shadow">
          <PrescriptionEditor text={extractedText} onConfirm={handleConfirm} />
        </div>
      </div>
    </div>
  );
}