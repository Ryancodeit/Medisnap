import { useNavigate } from 'react-router-dom';
import { clearStorage } from '../components/Storage';
import LanguageToggle from '../components/LanguageToggle';
import ThemeToggle from '../components/ThemeToggle';

export default function SettingsPage() {
  const navigate = useNavigate();

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset all data? This cannot be undone.')) {
      clearStorage();
      navigate('/');
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Settings</h2>
        </div>
        
        <div className="mt-8 bg-white p-6 rounded-lg shadow space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-gray-700">Dark Mode</span>
            <ThemeToggle />
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-700">Language</span>
            <LanguageToggle />
          </div>
          
          <div className="pt-4 border-t border-gray-200">
            <button
              onClick={handleReset}
              className="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
            >
              Reset All Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}