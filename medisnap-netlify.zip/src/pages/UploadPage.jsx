import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PrescriptionUploader from '../components/PrescriptionUploader';

export default function UploadPage() {
  const navigate = useNavigate();
  
  const handleTextExtracted = (text) => {
    navigate('/confirm', { state: { extractedText: text } });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Upload Prescription</h2>
          <p className="mt-2 text-sm text-gray-600">
            Take a photo or upload an image of your prescription
          </p>
        </div>
        
        <div className="mt-8">
          <PrescriptionUploader onTextExtracted={handleTextExtracted} />
        </div>
      </div>
    </div>
  );
}