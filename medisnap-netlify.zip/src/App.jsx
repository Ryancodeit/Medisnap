import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UploadPage from './pages/UploadPage';
import ConfirmPage from './pages/ConfirmPage';
import DashboardPage from './pages/DashboardPage';
import SettingsPage from './pages/SettingsPage';
import { useEffect } from 'react';
import { setupReminders } from './components/ReminderManager';
import { getPrescriptions } from './components/Storage';

export default function App() {
  useEffect(() => {
    // Initialize reminders on app load
    const prescriptions = getPrescriptions();
    setupReminders(prescriptions);
    
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/serviceWorker.js');
    }
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/upload" element={<UploadPage />} />
        <Route path="/confirm" element={<ConfirmPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Routes>
    </Router>
  );
}