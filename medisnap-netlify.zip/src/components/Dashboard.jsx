import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getPrescriptions, markDoseTaken, removePrescription } from './Storage';
import { setupReminders } from './ReminderManager';

export default function Dashboard() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const storedPrescriptions = getPrescriptions();
    setPrescriptions(storedPrescriptions);
    setupReminders(storedPrescriptions);
    
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, []);

  const handleMarkTaken = (id) => {
    const updated = markDoseTaken(id);
    setPrescriptions(updated);
  };

  const handleRemove = (id) => {
    const updated = removePrescription(id);
    setPrescriptions(updated);
  };

  const nextDoseTime = (frequency) => {
    // Simplified example - real implementation would calculate based on frequency
    const now = new Date();
    now.setHours(now.getHours() + 4);
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Your Medications</h1>
        <Link to="/upload" className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg">
          + Add Prescription
        </Link>
      </div>

      {prescriptions.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">No medications added yet</p>
          <Link to="/upload" className="text-blue-500 font-medium">
            Upload your first prescription
          </Link>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {prescriptions.map(pres => (
            <div key={pres.id} className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">{pres.name}</h3>
                  <p className="text-gray-600">{pres.dosage}</p>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleMarkTaken(pres.id)}
                    className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm"
                  >
                    Mark Taken
                  </button>
                  <button 
                    onClick={() => handleRemove(pres.id)}
                    className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm"
                  >
                    Remove
                  </button>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Frequency:</span>
                  <span>{pres.frequency}</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-gray-500">Next Dose:</span>
                  <span className="font-medium">{nextDoseTime(pres.frequency)}</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-gray-500">Last Taken:</span>
                  <span>
                    {pres.taken.length > 0 
                      ? new Date(pres.taken[pres.taken.length-1]).toLocaleTimeString() 
                      : 'Never'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}