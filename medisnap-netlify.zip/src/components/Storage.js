const PRESCRIPTIONS_KEY = 'medisnap_prescriptions';
const SETTINGS_KEY = 'medisnap_settings';

// Prescription Storage
export const savePrescription = (data) => {
  const prescriptions = JSON.parse(localStorage.getItem(PRESCRIPTIONS_KEY) || '[]');
  const newPres = {
    ...data,
    id: Date.now(),
    createdAt: new Date().toISOString(),
    taken: []
  };
  const updated = [...prescriptions, newPres];
  localStorage.setItem(PRESCRIPTIONS_KEY, JSON.stringify(updated));
  return newPres;
};

export const getPrescriptions = () => {
  return JSON.parse(localStorage.getItem(PRESCRIPTIONS_KEY) || '[]');
};

export const markDoseTaken = (id) => {
  const prescriptions = getPrescriptions();
  const updated = prescriptions.map(p => {
    if (p.id === id) {
      const taken = [...p.taken, new Date().toISOString()];
      return { ...p, taken };
    }
    return p;
  });
  localStorage.setItem(PRESCRIPTIONS_KEY, JSON.stringify(updated));
  return updated;
};

export const removePrescription = (id) => {
  const prescriptions = getPrescriptions();
  const updated = prescriptions.filter(p => p.id !== id);
  localStorage.setItem(PRESCRIPTIONS_KEY, JSON.stringify(updated));
  return updated;
};

// Settings Storage
export const getSettings = () => {
  const defaultSettings = {
    darkMode: false,
    language: 'en',
    notifications: true
  };
  const saved = localStorage.getItem(SETTINGS_KEY);
  return saved ? JSON.parse(saved) : defaultSettings;
};

export const saveSettings = (settings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  return settings;
};

// Clear all data
export const clearStorage = () => {
  localStorage.removeItem(PRESCRIPTIONS_KEY);
  localStorage.removeItem(SETTINGS_KEY);
  return { prescriptions: [], settings: getSettings() };
};