let reminderIntervals = {};

export const setupReminders = (prescriptions) => {
  // Clear existing reminders
  Object.values(reminderIntervals).forEach(clearInterval);
  reminderIntervals = {};

  prescriptions.forEach(pres => {
    const interval = getFrequencyInMs(pres.frequency);
    
    if (interval) {
      reminderIntervals[pres.id] = setInterval(() => {
        if (Notification.permission === 'granted') {
          new Notification('MediSnap Reminder', {
            body: `Time to take ${pres.name} - ${pres.dosage}`
          });
        }
      }, interval);
    }
  });
};

const getFrequencyInMs = (freq) => {
  const match = freq.match(/\d+/);
  if (!match) return null;
  
  const count = parseInt(match[0]);
  if (freq.includes('daily') || freq.includes('per day') || freq.includes('times a day')) {
    return 24 * 60 * 60 * 1000 / count;
  }
  if (freq.includes('hourly')) {
    return 60 * 60 * 1000 / count;
  }
  if (freq.includes('weekly')) {
    return 7 * 24 * 60 * 60 * 1000 / count;
  }
  return null;
};

export const requestNotificationPermission = () => {
  if (!('Notification' in window)) {
    console.log('This browser does not support notifications.');
    return;
  }
  
  Notification.requestPermission().then(permission => {
    if (permission === 'granted') {
      console.log('Notification permission granted.');
    }
  });
};