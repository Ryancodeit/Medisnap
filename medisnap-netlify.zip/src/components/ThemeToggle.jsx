import { useEffect } from 'react';
import { getSettings, saveSettings } from './Storage';

export default function ThemeToggle() {
  const settings = getSettings();
  
  const toggleTheme = () => {
    const newSettings = { ...settings, darkMode: !settings.darkMode };
    saveSettings(newSettings);
    applyTheme(newSettings.darkMode);
  };

  const applyTheme = (darkMode) => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  useEffect(() => {
    applyTheme(settings.darkMode);
  }, []);

  return (
    <button 
      onClick={toggleTheme}
      className="p-2 rounded-full bg-gray-200 dark:bg-gray-700"
    >
      {settings.darkMode ? '🌞' : '🌙'}
    </button>
  );
}