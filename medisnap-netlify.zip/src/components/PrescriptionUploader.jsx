import { useState } from 'react';
import { createWorker } from 'tesseract.js';

export default function PrescriptionUploader({ onTextExtracted }) {
  const [progress, setProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  const processImage = async (file) => {
    setIsProcessing(true);
    setProgress(0);
    
    const worker = await createWorker({
      logger: progress => {
        if (progress.status === 'recognizing text') {
          setProgress(Math.round(progress.progress * 100));
        }
      }
    });
    
    await worker.load();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');
    const { data: { text } } = await worker.recognize(file);
    await worker.terminate();
    
    setIsProcessing(false);
    onTextExtracted(text);
  };

  return (
    <div className="w-full max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      {isProcessing ? (
        <div className="text-center">
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <p className="mt-2 text-gray-600">Processing image... {progress}%</p>
        </div>
      ) : (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer">
          <input 
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files[0] && processImage(e.target.files[0])}
            className="hidden"
            id="prescription-upload"
          />
          <label htmlFor="prescription-upload" className="cursor-pointer">
            <div className="flex flex-col items-center justify-center">
              <svg className="w-12 h-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              <p className="text-gray-700 font-medium">Upload prescription image</p>
              <p className="text-gray-500 text-sm mt-1">or take a photo</p>
            </div>
          </label>
        </div>
      )}
    </div>
  );
}