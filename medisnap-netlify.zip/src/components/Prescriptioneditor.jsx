import { useState, useEffect } from 'react';
import nlp from 'compromise';

export default function PrescriptionEditor({ text, onConfirm }) {
  const [medData, setMedData] = useState({
    name: '',
    dosage: '',
    frequency: '',
    duration: ''
  });

  useEffect(() => {
    if (!text) return;
    
    const doc = nlp(text);
    const medName = doc.match('#Drug').out('text') || '';
    
    // Extract patterns using regex
    const dosageMatch = text.match(/\b\d+\s*(mg|g|ml)\b/i);
    const freqMatch = text.match(/\b\d+\s*(times|daily|per day)\b/i);
    const durationMatch = text.match(/\b\d+\s*(days|weeks|months)\b/i);
    
    setMedData({
      name: medName,
      dosage: dosageMatch?.[0] || '',
      frequency: freqMatch?.[0] || '1 daily',
      duration: durationMatch?.[0] || '7 days'
    });
  }, [text]);

  const handleChange = (field, value) => {
    setMedData({
      ...medData,
      [field]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onConfirm(medData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Medication Name</label>
        <input
          type="text"
          value={medData.name}
          onChange={(e) => handleChange('name', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Dosage</label>
        <input
          type="text"
          value={medData.dosage}
          onChange={(e) => handleChange('dosage', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Frequency</label>
        <input
          type="text"
          value={medData.frequency}
          onChange={(e) => handleChange('frequency', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Duration</label>
        <input
          type="text"
          value={medData.duration}
          onChange={(e) => handleChange('duration', e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          required
        />
      </div>
      
      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Confirm & Save
      </button>
    </form>
  );
}