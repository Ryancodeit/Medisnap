import { useEffect } from 'react';
import { requestNotificationPermission } from '../components/ReminderManager';

export default function useNotifications() {
  useEffect(() => {
    // Request notification permission on first load
    requestNotificationPermission();
  }, []);
}